create function regexp_matches(citext, citext) returns SETOF text[]
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT pg_catalog.regexp_matches( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;
