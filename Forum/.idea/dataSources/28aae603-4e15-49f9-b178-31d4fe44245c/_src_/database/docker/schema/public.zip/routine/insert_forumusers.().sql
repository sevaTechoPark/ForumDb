create function insert_forumusers() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  LOCK TABLE ForumUsers IN SHARE ROW EXCLUSIVE MODE;
  RETURN NULL;
END;
$$;
