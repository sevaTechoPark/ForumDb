create function insert_forumusers() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  LOCK TABLE ForumUsers IN ROW EXCLUSIVE MODE;
  INSERT INTO ForumUsers(userId, forumId) VALUES (NEW.userId, NEW.forumId) ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;
