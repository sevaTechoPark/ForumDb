create function insert_forumusers() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO ForumUsers(userId, forumId) VALUES (NEW.userId, NEW.forumId) ON CONFLICT DO UPDATE SET userId = NEW.userId;
  RETURN NEW;
END;
$$;
